package com.example.Ativdade;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtivdadeApplicationTests {

	@Test
	void contextLoads() {
	}

}
