package com.example.Ativdade;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class CalculatorController {
    private final CalculatorService calculatorService;

    @Autowired
    public CalculatorController(CalculatorService calculatorService) {
        this.calculatorService = calculatorService;
    }

    public void performOperations() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o primeiro número: ");
        int a = scanner.nextInt();

        System.out.print("Digite o segundo número: ");
        int b = scanner.nextInt();

        System.out.println("Escolha a operação: ");
        System.out.println("1. Adição");
        System.out.println("2. Subtração");
        System.out.println("3. Multiplicação");
        System.out.println("4. Divisão");

        int operation = scanner.nextInt();
        int result;

        switch (operation) {
            case 1:
                result = calculatorService.add(a, b);
                System.out.println("Resultado da adição: " + result);
                break;
            case 2:
                result = calculatorService.subtract(a, b);
                System.out.println("Resultado da subtração: " + result);
                break;
            case 3:
                result = calculatorService.multiply(a, b);
                System.out.println("Resultado da multiplicação: " + result);
                break;
            case 4:
                try {
                    result = calculatorService.divide(a, b);
                    System.out.println("Resultado da divisão: " + result);
                } catch (ArithmeticException e) {
                    System.out.println("Erro: " + e.getMessage());
                }
                break;
            default:
                System.out.println("Operação inválida.");
        }

        scanner.close();
    }
}
